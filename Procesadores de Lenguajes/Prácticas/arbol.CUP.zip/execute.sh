cup Arbol.cup #lanzamos cup
echo "==============="
jflex Arbol.flex #lanzamos flex
echo "==============="
javac *.java #compilamos los .java
java Arbol $1 #ejecutamos el programa con el fichero $1

