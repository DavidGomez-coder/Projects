cup Matrices.cup
jflex Matrices.flex
javac *.java
echo "Salida ... "
java Matrices $1.mat
