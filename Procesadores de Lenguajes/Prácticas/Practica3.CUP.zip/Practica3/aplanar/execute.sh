cup Test.cup
jflex Test.flex
javac *.java
java Test $1
