public class Yytoken {

    //costantes de clase
    public static final int PALABRA = 1;
    public static final int LINEA = 2;
    public static final int CARACTER = 3;
    public static final int OTROS = 100;

    //parámetros de clase
    private int token;
    private int valor; //guardamos en valor la longitud de la palabra,
                      // para así poder contar los caracteres

    public Yytoken(int token, int valor) {
         this.token = token;
         this.valor = valor;
    }
    public Yytoken(int token, String lexema) {
         this(token, Integer.parseInt(lexema));
    }

    public int getToken()  {
         return token;
    }

    public int getValor() {
         return valor;
    }

    public String toString() {
         return "<"+token+","+valor+">";
    }
}
