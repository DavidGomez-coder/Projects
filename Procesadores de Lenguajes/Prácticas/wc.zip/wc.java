import java.io.*;
import java.io.IOException;
import java.util.*;
import java.*;

public class wc {
	//inicialización de variables
	private static int LINEAS = 0; //
	private static int PALABRAS = 0;
	private static int CARACTERES = 0;

	public static void main (String[] args){
		if (args.length > 0) {
			try {
				Yylex lex = new Yylex(new FileReader(args[0]));
				Yytoken yytoken = null;
				while ( (yytoken = lex.yylex()) != null  ) {
					if(yytoken.getToken()==Yytoken.LINEA){
						LINEAS++;
						CARACTERES++; //los saltos de línea se cuentan como carácter
					}else if (yytoken.getToken()==Yytoken.PALABRA){
						PALABRAS++;
						//aumentamos los caracteres según el valor del yytoken, ya que
						//en este guardamos la longitud de la cadena leída
						CARACTERES+=yytoken.getValor();
					}else if (yytoken.getToken()==Yytoken.CARACTER){
						CARACTERES++;
					}
				}
					System.out.println(LINEAS + " " + PALABRAS + " " + CARACTERES + " " + args[0]);
			}catch (IOException e){
				System.err.println("Fichero no encontrado " + e.getStackTrace());
			}
		}
	}
}
